<?php $this->beginBlock('block1'); ?>

...content of block1...

<?php $this->endBlock(); ?>



<?php $this->beginBlock('block3'); ?>

...content of block3...

<?php $this->endBlock(); ?>









<h1><?= $hello ?></h1>

<h2><?php echo $hello; ?></h2>


