<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/10/28
 * Time: 10:04
 */

namespace app\modules\models;


use yii\base\Model;

class Owner extends Model {
    public $name;
}