<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/10/28
 * Time: 9:59
 */

namespace app\modules\models;


use yii\base\Model;

class Demo extends Model {
    public $name;
    public $age;

    public $owner;

}