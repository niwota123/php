<?php

use yii\bootstrap\ActiveForm;
use yii\bootstrap\Html;
use yii\widgets\ListView;
use yii\data\ActiveDataProvider;
use yii\grid\GridView;

$dataProvider = new ActiveDataProvider([
    'query' => \backend\models\Events::find(),
    'pagination' => [
        'pageSize' => 3,
    ],
        ]);
?>
<!-- Start Page Header -->
<div class="page-header">
    <h1 class="title">活动列表</h1>
    <ol class="breadcrumb">
        <li><a href="index.html">面板</a></li>
        <li><a href="#">活动</a></li>
        <li class="active">列表</li>
    </ol>

    <!-- Start Page Header Right Div -->
    <div class="right">
        <div class="btn-group" role="group" aria-label="...">
            <a href="index.html" class="btn btn-light">Dashboard</a>
            <a href="#" class="btn btn-light"><i class="fa fa-refresh"></i></a>
            <a href="#" class="btn btn-light"><i class="fa fa-search"></i></a>
            <a href="#" class="btn btn-light" id="topstats"><i class="fa fa-line-chart"></i></a>
        </div>
    </div>
    <!-- End Page Header Right Div -->

</div>
<!-- End Page Header -->


<!-- //////////////////////////////////////////////////////////////////////////// --> 
<!-- START CONTAINER -->
<div class="container-default">
    <div class="row">
        <div class="col-sm-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <?php
                    echo GridView::widget([
                        'dataProvider' => $dataProvider,
                        'filterModel' => new \backend\models\EventsSearchModel(),
                        'columns' => [
                            ['class' => 'yii\grid\SerialColumn'],
                            // 数据提供者中所含数据所定义的简单的列
                            // 使用的是模型的列的数据
                            'id',
                            'event_name',
                            'event_thumb',
                            'event_area',
                            [
                                'class' => 'yii\grid\ActionColumn',
                                'template' => '<span>{view}</span><span>{delete}</span>',
                                'buttons' => [
                                    'view' => function ($url, $model, $key) {
                                        return Html::a('显示', ['view', 'id' => $key], ['class' => 'btn btn-sm btn-info']);
                                    },
                                    'delete' => function ($url, $model, $key) {
                                        return Html::a('删除', ['delete', 'id' => $key], ['class' => 'btn btn-sm btn-primary']);
                                    }
                                ],
                                'options' => [
                                    'width' => 200
                                ]
                            ],
                            
                        ]
                    ]);
                    ?>

                </div>
            </div>

        </div>
    </div>
</div>
<!-- END CONTAINER -->
<!-- //////////////////////////////////////////////////////////////////////////// --> 
