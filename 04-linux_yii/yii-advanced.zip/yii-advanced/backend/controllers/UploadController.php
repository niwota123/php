<?php

namespace backend\controllers;

use backend\models\Upload;
use Yii;
use yii\web\Controller;
use yii\web\UploadedFile;

class UploadController extends Controller {

    public $layout = false;

//    public $enableCsrfValidation = false;

    /**
     * 上传图片
     */
    public function actionImage() {
        Yii::$classMap['http'] = '@vendor/http/http.class.php';
        $model = new Upload();
        
        if (Yii::$app->request->isPost) {
            $model->file = UploadedFile::getInstance($model, 'file');
            
            $filename = Yii::$app->security->generateRandomString(32) . "." . $model->file->extension;
            if ($model->validate()) {
                $baseFilePath = "/frontend/web/uploads/" . date("Ymd") . "/";
                $filepath = dirname(dirname(Yii::getAlias('@webroot'))) . $baseFilePath;
                if (!is_dir($filepath)) {
                    mkdir($filepath, '0777', true);
                }

                if (!Yii::$app->request->isSecureConnection) {
                    $baseUrl = "http://" . Yii::$app->request->serverName;
                } else {
                    $baseUrl = "https://" . Yii::$app->request->serverName;
                }
                if (Yii::$app->request->serverPort != '80') {
                    $baseUrl = $baseUrl . ":" . Yii::$app->request->serverPort;
                }

                $model->file->saveAs($filepath . $filename);

                $url = $baseUrl . $baseFilePath . $filename;
                return $this->render('image', [
                            'model' => $model,
                            'url' => $url
                ]);

                /*
                  $http = new \http();
                  $url = "http://www.pc9.la/upload.php";
                  $password = '123456';
                  $time = time();
                  $token = md5($model->file->name . $model->file->extension . $password . $time);
                  $http->upload($url, [
                  //                    'password' => $password
                  'time' => $time,
                  'token' => $token,
                  'name' => $model->file->name,
                  'extenstion' => $model->file->extension
                  ], [
                  'file' => $model->file->tempName
                  ]);
                  $message = $http->data;
                  echo $message;
                 * 
                 */
            }
        }


        return $this->render('image', [
                    'model' => $model
        ]);
    }

    /**
     * 上传文件
     */
    public function actionFile() {
        
    }

    public function actionWebuploader() {
        Yii::$classMap['http'] = '@vendor/http/http.class.php';
        $model = new Upload();

        if (Yii::$app->request->isPost) {
            $model->file = UploadedFile::getInstanceByName('file');
            
            $filename = Yii::$app->security->generateRandomString(32) . "." . $model->file->extension;
            if ($model->validate()) {
                $baseFilePath = "/frontend/web/uploads/" . date("Ymd") . "/";
                $filepath = dirname(dirname(Yii::getAlias('@webroot'))) . $baseFilePath;
                if (!is_dir($filepath)) {
                    mkdir($filepath, '0777', true);
                }

                if (!Yii::$app->request->isSecureConnection) {
                    $baseUrl = "http://" . Yii::$app->request->serverName;
                } else {
                    $baseUrl = "https://" . Yii::$app->request->serverName;
                }
                if (Yii::$app->request->serverPort != '80') {
                    $baseUrl = $baseUrl . ":" . Yii::$app->request->serverPort;
                }

                $model->file->saveAs($filepath . $filename);

                $url = $baseUrl . $baseFilePath . $filename;
                
                $result = [
                    'stauts' => 2000,
                    'message' => 'Success',
                    'url' => $url
                ];
                Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
                return $result;

                /*
                  $http = new \http();
                  $url = "http://www.pc9.la/upload.php";
                  $password = '123456';
                  $time = time();
                  $token = md5($model->file->name . $model->file->extension . $password . $time);
                  $http->upload($url, [
                  //                    'password' => $password
                  'time' => $time,
                  'token' => $token,
                  'name' => $model->file->name,
                  'extenstion' => $model->file->extension
                  ], [
                  'file' => $model->file->tempName
                  ]);
                  $message = $http->data;
                  echo $message;
                 * 
                 */
            }
        }
    }

}
