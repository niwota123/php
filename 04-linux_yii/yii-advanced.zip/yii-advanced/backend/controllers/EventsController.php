<?php

namespace backend\controllers;
use backend\models\Events;
use yii\web\Controller;

class EventsController extends  Controller {

    public function actionIndex() {
        return $this->render('index');
    }

    public function actionAdd() {

        $model = new Events();

        if (\Yii::$app->request->isPost){
            if ($model->load(\Yii::$app->request->post())&&$model->validate()){


                $model->event_area = \Yii::$app->request->post('event_province').','.\Yii::$app->request->post('event_city').','.\Yii::$app->request->post('event_district');

                $model->save();

                return $this->goBack();
            }
        }

        return $this->render('add', [
            'model' => $model
        ]);
    }
    
    public function actionEdit() {
        
    }

    public function actionDelete() {
        
    }

}
