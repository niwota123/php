<?php

namespace backend\controllers;

use Yii;
use backend\models\Region;
use yii\web\Controller;

class RegionController extends Controller {

    /**
     * 获取某个省份的市区列表
     */
    public function actionAjaxcities() {
        $id = (int) Yii::$app->request->get('id');

        $result = [0 => '请选择'];
        
        $model = new Region();
        $row = $model->getListsByParentId($id);
        if (!empty($row)) {
            foreach ($row as $k => $v) {
                $result[$v['id']] = $v['name'];
            }
        }
        
        Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        return $result;
    }

}
