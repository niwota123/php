/*
Navicat MySQL Data Transfer

Source Server         : local
Source Server Version : 50629
Source Host           : localhost:3306
Source Database       : test_db

Target Server Type    : MYSQL
Target Server Version : 50629
File Encoding         : 65001

Date: 2017-08-22 10:14:50
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for score
-- ----------------------------
DROP TABLE IF EXISTS `score`;
CREATE TABLE `score` (
  `sno` varchar(20) NOT NULL,
  `cno` varchar(20) NOT NULL,
  `degree` decimal(10,0) DEFAULT NULL,
  KEY `sno` (`sno`),
  KEY `cno` (`cno`),
  CONSTRAINT `score_ibfk_1` FOREIGN KEY (`sno`) REFERENCES `student` (`sno`),
  CONSTRAINT `score_ibfk_2` FOREIGN KEY (`cno`) REFERENCES `course` (`cno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of score
-- ----------------------------
INSERT INTO `score` VALUES ('103', '3-245', '86');
INSERT INTO `score` VALUES ('105', '3-245', '75');
INSERT INTO `score` VALUES ('109', '3-245', '68');
INSERT INTO `score` VALUES ('103', '3-105', '92');
INSERT INTO `score` VALUES ('105', '3-105', '88');
INSERT INTO `score` VALUES ('109', '3-105', '76');
INSERT INTO `score` VALUES ('103', '3-105', '64');
INSERT INTO `score` VALUES ('105', '3-105', '91');
INSERT INTO `score` VALUES ('109', '3-105', '78');
INSERT INTO `score` VALUES ('103', '6-166', '85');
INSERT INTO `score` VALUES ('105', '6-166', '79');
INSERT INTO `score` VALUES ('109', '6-166', '81');
